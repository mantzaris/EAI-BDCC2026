Graph Representations for Congestion Onset Prediction: A Controlled Comparative Study
Revised source with author information

Authors (in order): John Z Willis; Alexander V. Mantzaris (corresponding author);
James H. Korris.

main.tex is the revised manuscript (main_revised.tex in the working repository).
main.pdf is its compiled PDF. main.bbl is the generated bibliography.
The archive includes all project-specific compilation dependencies and the
original Springer template files. It does not require the research repository.

Build from this directory with a standard TeX Live or MiKTeX installation:

  pdflatex -halt-on-error -interaction=nonstopmode main.tex
  bibtex main
  pdflatex -halt-on-error -interaction=nonstopmode main.tex
  pdflatex -halt-on-error -interaction=nonstopmode main.tex

Required distribution packages include graphicx, booktabs, tabularx, amsmath,
amssymb, accsupp, hyperref, and glyphtounicode. The class and BibTeX style are
included locally. Figure descriptions are provided in ALT_TEXT.md.
